/***********************************************
 * Project : emptyProject
 * date : Fri Jan 22 02:05:07 2016
 ***********************************************/

// precompiled headers.
#include "stdafx.h"
